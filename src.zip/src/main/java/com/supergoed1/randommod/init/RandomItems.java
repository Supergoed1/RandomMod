package com.supergoed1.randommod.init;

import com.supergoed1.randommod.items.IronStick;

import net.minecraft.item.Item;

public class RandomItems {

	public static final IronStick IRONSTICK = new IronStick();
	
	public static final Item[] ITEMS = {

			IRONSTICK

		};
	
	
}
